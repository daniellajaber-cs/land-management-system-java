package project1;

public interface LandPrice {
	double priceOfLand();
	// every class that uses this inference must have this method 
	// and this inference calculates the price of land 

}
